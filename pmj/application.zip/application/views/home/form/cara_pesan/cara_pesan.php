<div class="tab-content">
	

	<div class="tab-pane  active" id="blockView">
		<h4>Cara Pemesanan</h4>
		SEPERTI INI

	<hr class="soft">
	</div>
</div>