<div class="box">
  <div class="box-body">
          <!-- Widget: user widget style 1 -->
          <div class="box box-widget widget-user">
            <!-- Add the bg color to the header using any of the bg-* classes -->
            <div class="widget-user-header bg-aqua-active">
              
              <h5 class="widget-user-desc">Selamat datang di halaman administrator</h5>
              <h3 class="widget-user-username"><?php echo $user['nama'] ?></h3>
              <h4><?php echo $user['jabatan'] ?></h4>
            </div>
            
          </div>
          <!-- /.widget-user -->




    </div>
</div>