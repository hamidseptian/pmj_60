



<div class="logo">
  <img src="<?php echo base_url() ?>file/logo.PNG" >
</div>
<div >
    <div class="kop">
      <div><b>GELATO ROMANCE</b></div>
      <div class="alamat">
        Jl. Belkang Pasar Siteba No. 35, Nanggalo, Padang <br> Email : romancegelato@gmail.com <br>  
      HP : 081221758374
    </div>


     
    </div>
  </div>
  <div class="clearfix"></div>

<div class="garis_kop1"></div>
<div class="garis_kop2"></div>




