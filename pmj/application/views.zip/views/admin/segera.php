<div class="box-body">
  Fitur ini belum tersedia
</div>