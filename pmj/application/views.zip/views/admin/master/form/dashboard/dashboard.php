
          <!-- Widget: user widget style 1 -->
          <div class="box box-widget widget-user">
            <br>
              <div class="col-md-12">
            <!-- Add the bg color to the header using any of the bg-* classes -->
            <div class="widget-user-header bg-aqua-active">
                 <h5 class="widget-user-desc">Selamat datang di halaman administrator</h5>
              <h3 class="widget-user-username"><?php echo $this->session->userdata('nama_user') ?></h3>
              <h4>Admin Master</h4>
            </div>
            
          </div>
          <div class="clearfix"></div>
        </div>
          <!-- /.widget-user -->



<div class="row">
  <div class="col-md-12">
    
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php echo $toko ?></h3>

              <p>Mitra</p>
            </div>
            <div class="icon">
              <i class="ion ion-bag"></i>
            </div>
            <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
    
        <!-- ./col -->
      </div>
  </div>