<div class="box-header">
	<h3 class="box-title">Catatan <small>Persentasi program 75%</small></h3>
	
</div>
<div class="box-body">
	<ul>
		<li>Print  faktur pemesanan</li>
		<li>Print  laporan barang, pesanan, penjualan, pesanan diantar</li>
		<li>Print  laporan mitra</li>
		<!-- <li>tambahkan kolom waktu pesan di tabel pesanan beserta fitur2 yang terlibat di koding</li> -->
		<!-- <li>isi data kategori barang dan relasikan</li> -->
		<!-- <li>tampilkan kategori di homepage</li> -->
		<!-- <li>pencarian data berdasarkan kategori yang dipilih</li> -->
	
		<li>halaman dashboard</li>

	</ul>
</div>